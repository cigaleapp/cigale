import{e as f,u as t}from"./CJTnYVIR.js";function o({title:e}){c(()=>{document.title=e?`${e} · Cigale`:"Cigale"})}function c(e){if(f()){e();return}t(()=>{e()})}export{o as s};
