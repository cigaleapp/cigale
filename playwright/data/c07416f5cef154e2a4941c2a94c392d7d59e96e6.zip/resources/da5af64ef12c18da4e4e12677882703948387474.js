import{l as o,f as r}from"../chunks/5kycoPHn.js";export{o as load_css,r as start};
